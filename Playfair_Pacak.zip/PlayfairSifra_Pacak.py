#!/usr/bin/python
# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import QApplication, QPlainTextEdit, \
    QLineEdit, QPushButton, QLabel, \
    QMainWindow, QMessageBox,QDialog, QRadioButton

from PyQt5 import uic
import sys
import math
import re


class MyWindow(QMainWindow):

     # Propojení .ui souboru s .py souborem.

    def __init__(self):
        super(MyWindow, self).__init__()
        uic.loadUi("PlayfairUI.ui",self)
       

        self.textBoxOT= self.findChild(QPlainTextEdit,"textBoxOT")
        self.textBoxCT= self.findChild(QPlainTextEdit,"textBoxCT")
        self.keyword= self.findChild(QLineEdit,"keyword")
        self.cipherButton= self.findChild(QPushButton,"cipherButton")
        self.decipherButton= self.findChild(QPushButton,"decipherButton")
        self.radioCZ=self.findChild(QRadioButton,"radioCZ")
        self.radioSK=self.findChild(QRadioButton,"radioSK")

        self.cipherButton.clicked.connect(self.cipherButton_clicked)
        self.decipherButton.clicked.connect(self.decipherButton_clicked)
        self.show()
    
    def cipherButton_clicked(self):
        textOT= self.textBoxOT.toPlainText().upper().strip()
        self.cipher(textOT)

    def decipherButton_clicked(self):
        textCT=self.textBoxCT.toPlainText().upper().strip()
        self.decipher(textCT)




    def cipher(self, text):

        alphabet = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
        keywordText=self.keyword.text().upper()
        if self.is_text_ok(text) and self.check_for_repeating_letters_and_if_ok(keywordText):
            
            keywordText=self.remove_spaces_and_replace_left_out(keywordText)
            #QMessageBox.about(self,"Chyba",keywordText)
            OT=self.replace_numbers_with_words(text)
            OT=self.remove_spaces_and_replace_left_out(OT)
            OT=self.add_letter_if_odd(OT)
            alphabet=self.remove_character_from_alpha(alphabet).strip()
            alphabet=self.insert_keyword_to_alphabet(alphabet,keywordText)
            #QMessageBox.about(self,"Chyba",OT)
            rows,cols=(5,5)
            MultidimesnionalAlphabet = [[0 for i in range(cols)] for j in range(rows)]
            self.multidimensional_array(MultidimesnionalAlphabet,alphabet,rows,cols)
            
            Matrix = [[0 for x in range(rows)] for y in range(cols)]
           
      
            CT=""
            pair=""
            for i in range(0,len(OT),2):
                pair = pair + OT[i]+OT[i+1]
                CT=self.cipher_character_pair(pair,MultidimesnionalAlphabet,CT)
                pair=""

            self.textBoxCT.setPlainText(self.split_into_fives(CT))

        else:
            QMessageBox.about(self,"Chyba","Enter correct keyword / text")


    def decipher(self, text):
        keywordText=self.keyword.text().upper()
        alphabet = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
        if self.is_text_ok(text) and self.check_for_repeating_letters_and_if_ok(keywordText):
            
            keywordText=self.remove_spaces_and_replace_left_out(keywordText)

            CT=self.replace_numbers_with_words(text)
            CT=self.remove_spaces_and_replace_left_out(CT)
            CT=self.add_letter_if_odd(CT)
            alphabet=self.remove_character_from_alpha(alphabet).strip()
            alphabet=self.insert_keyword_to_alphabet(alphabet,keywordText)
            #QMessageBox.about(self,"Chyba",OT)
            rows,cols=(5,5)
            MultidimesnionalAlphabet = [[0 for i in range(cols)] for j in range(rows)]
            self.multidimensional_array(MultidimesnionalAlphabet,alphabet,rows,cols)
        
            Matrix = [[0 for x in range(rows)] for y in range(cols)]
       
        
            OT=""
            pair=""
            for i in range(0,len(CT),2):
                pair = pair + CT[i]+CT[i+1]
                OT=self.decipher_charcter_pair(pair,MultidimesnionalAlphabet,OT)
                pair=""

            self.textBoxOT.setPlainText(OT)

        else:
            QMessageBox.about(self,"Chyba","Enter correct keyword / text")



    def split_into_fives(self,text):
        
        if(len(text)>5):
            newText=""
            counter=0
            for i in range(len(text)):
                newText=newText+text[i]
                counter=counter+1
                if(counter%5==0 and counter!=0):
                    newText=newText+" "
            return newText
        else:
            return text           


    def add_letter_if_odd(self,text):
        if(len(text)%2==1):
            if(text[len(text)-1]=="X"):
                text=text+"W"
            elif(text[len(text)-1]=="W"):
                text=text+"X"
            else:
                text=text+"X"
        return text

    def replace_numbers_with_words(self,text):
        newText=text
        newText=newText.replace("0","NULA")
        newText=newText.replace("1","JEDNA")
        newText=newText.replace("2","DVA")
        newText=newText.replace("3","TRI")
        newText=newText.replace("4","CTYRI")
        newText=newText.replace("5","PET")
        newText=newText.replace("6","SEST")
        newText=newText.replace("7","SEDM")
        newText=newText.replace("8","OSM")
        newText=newText.replace("9","DEVET")
        return newText
    def remove_spaces_and_replace_left_out(self,text): 
        
        newText=text
        if(self.radioCZ.isChecked()):
            newText=newText.replace(" ","")
            newText=newText.replace("Y","I")
        else:
            newText=newText.replace(" ","")
            newText=newText.replace("I","Y")
        return newText

    def check_for_repeating_letters_and_if_ok(self,keywordText):
        result=False
        result2=False
        counter=0
        for character in keywordText:
            if (bool(re.match('^[A-Z]*$',str(character)))):
                result2=True
            else:
                result2=False
                break
        return result2

        for i in keywordText:
            if keywordText.count(i)>1:
                result=False
                break
            else:
                result=True
        return result*result2

    def remove_character_from_alpha(self,alphabet):
        if(self.radioCZ.isChecked()):
            string="".join(alphabet)
            string=string.replace("Y","")
            #QMessageBox.about(self,"asda",string)
            alphabet=string.strip()
            return alphabet
        else:
            string="".join(alphabet)
            string=string.replace("I","")
            alphabet=string.strip()
            return alphabet

    def insert_keyword_to_alphabet(self,alphabet,keyword):
        newAlpha=[]
        for i in alphabet:
            newAlpha.append(i)
        
        for i in reversed(keyword):
            newAlpha.remove(i)
            newAlpha.insert(0,i)

        return newAlpha


    def cipher_character_pair(self,pair,alphabet,CT):
        pairF=[]
        pairS=[]
        newpair=[]

        #rows=5
        #cols=5
        #message=""
        #for i in range(rows):
        #    for j in range(cols):
        #       message=message+alphabet[i][j]
        #    message=message+" "
        #QMessageBox.about(self,"Chyba",message)

        if(pair[0]==pair[1]):
            npair=""
            npair=pair[0]+"X"
            pair=npair
        #QMessageBox.about(self,"Chyba",pair)
        for i in range(5):
            for j in range(5):
                if pair[0] == alphabet[i][j]:
                    r=""
                    r= r+str(i)+str(j)
                    #QMessageBox.about(self,"Chyba",r)
                    pairF.append(i)
                    pairF.append(j)
                elif pair[1] == alphabet[i][j]:
                    r=""
                    r= r+str(i)+str(j)
                    #QMessageBox.about(self,"Chyba",r)
                    pairS.append(i)
                    pairS.append(j)
        if(pairF[0]==pairS[0]):
            Fy=(pairF[1]+1)%5
            Sy=(pairS[1]+1)%5
            newpair.append(alphabet[pairF[0]][Fy])
            newpair.append(alphabet[pairS[0]][Sy])    
        elif(pairF[1]==pairS[1]):
            Fx=(pairF[0]+1)%5
            Sx=(pairS[0]+1)%5
            newpair.append(alphabet[Fx][pairF[1]])
            newpair.append(alphabet[Sx][pairS[1]])
        else:
            newpair.append(alphabet[pairF[0]][pairS[1]])
            newpair.append(alphabet[pairS[0]][pairF[1]])
           
        CT=CT+"".join(newpair)
        return CT

        #QMessageBox.about(self,"coordinace",CT)        

                       
    def decipher_charcter_pair(self,pair,alphabet,OT):
        pairF=[]
        pairS=[]
        newpair=[]

        #rows=5
        #cols=5
        #message=""
        #for i in range(rows):
        #    for j in range(cols):
        #       message=message+alphabet[i][j]
        #    message=message+" "
        #QMessageBox.about(self,"Chyba",message)
        #QMessageBox.about(self,"Chyba",pair)
        for i in range(5):
            for j in range(5):
                if pair[0] == alphabet[i][j]:
                    r=""
                    r= r+str(i)+str(j)
                    #QMessageBox.about(self,"Chyba",r)
                    pairF.append(i)
                    pairF.append(j)
                elif pair[1] == alphabet[i][j]:
                    r=""
                    r= r+str(i)+str(j)
                    #QMessageBox.about(self,"Chyba",r)
                    pairS.append(i)
                    pairS.append(j)
        if(pairF[0]==pairS[0]):
            Fy=(pairF[1]-1)%5
            Sy=(pairS[1]-1)%5
            newpair.append(alphabet[pairF[0]][Fy])
            newpair.append(alphabet[pairS[0]][Sy])    
        elif(pairF[1]==pairS[1]):
            Fx=(pairF[0]-1)%5
            Sx=(pairS[0]-1)%5
            newpair.append(alphabet[Fx][pairF[1]])
            newpair.append(alphabet[Sx][pairS[1]])
        else:
            newpair.append(alphabet[pairF[0]][pairS[1]])
            newpair.append(alphabet[pairS[0]][pairF[1]])
           
        OT=OT+"".join(newpair)
        return OT       
            

    def multidimensional_array(self,newArray,originalAray,rows,cols):
        counter=0
        for i in range(rows):
            for j in range(cols):
                newArray[i][j]=originalAray[counter]
                counter=counter+1

        rows,cols=5,5        
        message=""
        for i in range(rows):
            for j in range(cols):
               message=message+newArray[i][j]
            message=message+" "
        #QMessageBox.about(self,"Chyba",message+"asd")

       


    def is_text_ok(self, text):
        result1=True
        for character in text:
            if (bool(re.match('^[A-Z0-9]*$',str(character))) or str(character)==" "):
                result1=True
            else:
                result1=False
                break
        return result1


# Spuštění aplikace

app = QApplication(sys.argv)
win = MyWindow()
app.exec_()
