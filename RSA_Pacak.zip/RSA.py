from PyQt5.QtWidgets import QApplication, QPlainTextEdit, \
    QLineEdit, QPushButton, QLabel, \
    QMainWindow, QMessageBox,QDialog, QRadioButton, \
    QVBoxLayout

from PyQt5 import uic
import sys
import math
import random
import re





globalAlphabet = ["A","B","C","D","E",
            "F","G","H","I","J",
            "K","L","M","N","O",
            "P","Q","R","S","T",
            "U","V","W","X","Y",
            "Z","0","1","2","3",
            "4","5","6","7","8",
            "9"]
newAlphabet=[]
ListOfLabels=[]
from PyQt5.QtWidgets import QApplication, QPlainTextEdit, \
    QLineEdit, QPushButton, QLabel, \
    QMainWindow, QMessageBox,QDialog

from PyQt5 import uic
import sys
import math
import random
import re
import sympy
   
generatedKeys=False

class MyWindow(QMainWindow):


    def __init__(self):
        super(MyWindow, self).__init__()
        uic.loadUi("RSA.ui",self)
       
        self.OTtextBox=self.findChild(QPlainTextEdit,"OT")
        self.CTtextBox=self.findChild(QPlainTextEdit,"CT")
        self.Epart=self.findChild(QLineEdit,"Epart")
        self.Dpart=self.findChild(QLineEdit,"Dpart")
        self.RandomKeysButton=self.findChild(QPushButton,"RandomKeys")
        self.Npart=self.findChild(QLineEdit,"Npart")
        self.CipherButton=self.findChild(QPushButton,"CipherButton")
        self.DecipherButton=self.findChild(QPushButton,"DecipherButton")

        self.RandomKeysButton.clicked.connect(self.RandomKeysButton_push)
        self.CipherButton.clicked.connect(self.CipherButton_push)
        self.DecipherButton.clicked.connect(self.DecipherButton_push)






        self.show()

    def RandomKeysButton_push(self):
        p=random.randrange((1*math.pow(10,21)),(1*math.pow(10,22))-1)
        while(not sympy.isprime(p)):
            p=random.randrange((1*math.pow(10,21)),(1*math.pow(10,22))-1)
        q=random.randrange((1*math.pow(10,21)),(1*math.pow(10,22))-1)
        while(not sympy.isprime(q)):
            q=random.randrange((1*math.pow(10,21)),(1*math.pow(10,22))-1)
        N=p*q
        FiN=(p-1)*(q-1)
        E=random.randrange(1,FiN-1)
        D=0
        while(not math.gcd(E,FiN)==1):
           E=random.randrange(1,FiN-1)
        D=pow(E,-1,FiN)
        global generatedKeys
        generatedKeys=True
        self.Epart.setText(str(E))
        self.Dpart.setText(str(D))
        self.Npart.setText(str(N))

    def are_all_conditions_sattisfied(self,choice):
        result=True
        if choice==True:
            
            if not self.is_text_alright():
                QMessageBox.about(self,"Error","Use only letters from the ASCII table")
                result=False

            if not self.is_key_generated(choice):
                QMessageBox.about(self,"Error", "Insert or update parameters")
                result=False
        else:
            if not self.check_if_ct_are_diggit():
                QMessageBox.about(self,"Error", "Cipher text must contain only digits")
                result=False   

        return result

    def is_text_alright(self):
        result=True
        for letter in self.OTtextBox.toPlainText():
            if not letter.isascii():
                result=False
        return result




    def check_if_ct_are_diggit(self):
        result=True
        text=self.CTtextBox.toPlainText()
        for i in text:
            if i.isdigit() or i == " ":
                result=True
            else:
                result=False
                break
        return result

    def is_key_generated(self,choice):
        if choice:
            if generatedKeys:
                return True
            else:
                return False
        if not choice:
            if (self.Dpart.text!="") and (self.Npart!=""):
                return True
            else:
                return False


    def get_Ct_into_block(self):
        newArray=[]
        block=""
        text=self.CTtextBox.toPlainText()
        
        for character in text:
            if character != " ":
                block+=character
            else:
                newArray.append(block)
                block=""

       
            
        return newArray

    def convert_ct_block(self,newblock):
        block=pow(int(newblock),int(self.Dpart.text()),int(self.Npart.text()))
        binBlock=bin(block)[2:]

        #QMessageBox.about(self,"as",str(binBlock))
        if len(str(binBlock))%8 != 0:
           binBlock=(binBlock).zfill((len(str(binBlock))-len(str(binBlock))%8)+8)
           #QMessageBox.about(self,"as",str(str(binBlock)))
        
        binArray=[]
        
        for i in range(0,len(str(binBlock))-7,8):
            binArray.append(binBlock[i:i+8])
        asciiArray=[]
        
        for binary in binArray:
            
            asciiArray.append(chr(int(binary,2)))
        return ("".join(asciiArray))



    def get_Text_Into_Blocks(self):
        newArray=[]
        block=""
        text=self.OTtextBox.toPlainText()
        

        for i in range(0,len(text),6):
            if i<len(text)-6:
                newArray.append(text[i:i+6])
                
            else:
                #QMessageBox.about(self,"as",text[i:len(text)])
                newArray.append(text[i:len(text)])

        return newArray


    def convert_block(self,block):
        ConvertedAscii=[]
        ConvertedBinary=[]
        for character in block:
            ConvertedAscii.append(ord(character))
        for i in ConvertedAscii:
            #if len(str(bin(i))) != 8:
            convoBin=str((bin(i)[2:]).zfill(8))
            ConvertedBinary.append(str(convoBin))
            #else:
            #    ConvertedBinary.append(str((bin(i)[2:])))
        #QMessageBox.about(self,"as",str(ConvertedBinary))
        result="".join(ConvertedBinary)
        result=str(int(result,2))
        return result
        
    def final_convert_function():
        pass





    def CipherButton_push(self):
        if self.are_all_conditions_sattisfied(True):
            blockArray=self.get_Text_Into_Blocks()
            convertedBlock=[]
            for block in blockArray:
                convertedBlock.append(str(self.convert_block(block))+" ")
            newConvertedBlock=[]
            for block in convertedBlock:
                newConvertedBlock.append(str(pow(int(block), int(self.Epart.text()), int(self.Npart.text())))+" ")


            result="".join(newConvertedBlock)
            self.CTtextBox.setPlainText(result)

    def DecipherButton_push(self):
        if self.are_all_conditions_sattisfied(False):
            result=""
            blockArray=self.get_Ct_into_block()
            for block in blockArray:
                result+=self.convert_ct_block(int(block))
            self.OTtextBox.setPlainText(result)
app = QApplication(sys.argv)
win = MyWindow()
app.exec_()
    