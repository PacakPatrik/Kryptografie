from PyQt5.QtWidgets import QApplication, QPlainTextEdit, \
    QLineEdit, QPushButton, QLabel, \
    QMainWindow, QMessageBox,QDialog, QRadioButton, \
    QVBoxLayout

from PyQt5 import uic
import sys
import math
import random
import re





globalAlphabet = ["A","B","C","D","E",
            "F","G","H","I","J",
            "K","L","M","N","O",
            "P","Q","R","S","T",
            "U","V","W","X","Y",
            "Z","0","1","2","3",
            "4","5","6","7","8",
            "9"]
newAlphabet=[]
ListOfLabels=[]

class MyWindow(QMainWindow):

     # Propojení .ui souboru s .py souborem.


   
    def __init__(self):
        super(MyWindow, self).__init__()
        uic.loadUi("adfgxUI.ui",self)
       

        self.textBoxOT= self.findChild(QPlainTextEdit,"textBoxOT")
        self.textBoxCT= self.findChild(QPlainTextEdit,"textBoxCT")
        self.keyword= self.findChild(QLineEdit,"keyword")
        self.cipherButton= self.findChild(QPushButton,"cipherButton")
        self.decipherButton= self.findChild(QPushButton,"decipherButton")
        self.radioCZ=self.findChild(QRadioButton,"radioCZ")
        self.radioSK=self.findChild(QRadioButton,"radioSK")
        self.radioADFGX=self.findChild(QRadioButton,"adfgx")
        self.radioADFGVX=self.findChild(QRadioButton,"adfgvx")
        self.generateButton=self.findChild(QPushButton,"generateButton")
        self.matriceBox=self.findChild(QLineEdit,"matriceBox")

        self.matriceBox.textChanged.connect(self.matriceBox_textChanged)
        self.cipherButton.clicked.connect(self.cipherButton_push)
        self.decipherButton.clicked.connect(self.decipherButton_push)
        self.generateButton.clicked.connect(self.generateButton_push)
        global ListOfLabels 
        ListOfLabels= self.get_key_table_text()


        self.show()


    def cipherButton_push(self):
        self.Cipher(self.textBoxOT.toPlainText().upper())

    def decipherButton_push(self):
        self.Decipher(self.textBoxCT.toPlainText().upper())


    def matriceBox_textChanged(self): 
        text=self.matriceBox.text()
        if self.radioADFGVX.isChecked():
          
            if len(text) <=36:
            #QMessageBox.about(self,"",text)
                for label in ListOfLabels:
                    label.setText("___")

                for i in range(len(text)):
                    ListOfLabels[i].setText(text[i])
            else:
                pass
        else:
            if len(text) <=30:
               
            #QMessageBox.about(self,"",text)
                for label in ListOfLabels:
                    label.setText("___")

                counter=5
                for i in range(len(text)):
                    if i == counter:
                        counter=counter+6
                        continue

                    else:
                        ListOfLabels[i].setText(text[i])
                    
            else:
                pass



    def get_key_table_text(self):

        #Sjednocení tabulky lineEditů do jednoho pole

        counter=0
        ListOfLabels=[]
        for i in range(36):
            
            self.matriceText=self.findChild(QLabel,"t"+str(counter))
            counter=counter+1
            ListOfLabels.append(self.matriceText)
            ListOfLabels[i].setText("___")
        return ListOfLabels


    def remove_character_from_alpha(self,globalAlphabet):
        global newAlphabet
        newAlphabet.clear()
        if(self.radioCZ.isChecked()):
            string="".join(globalAlphabet)
            string=string.replace("Q","")
            for i in range(len(string)):
                newAlphabet.append(string[i])
            
                
        else:
            string="".join(globalAlphabet)
            string=string.replace("W","")
            globalAlphabet=string.strip()
            for i in range(len(string)):
                newAlphabet.append(string[i])
            
    def replace_left_out_letters(self,text): 
        
        newText=text
        if(self.radioCZ.isChecked()):
            newText=newText.replace("Q","KVE")
        else:
            newText=newText.replace("W","V")
        return newText

    def generateButton_push(self):
        self.remove_character_from_alpha(globalAlphabet)
        for label in ListOfLabels:
                            label.setText("___")
                
        if self.radioADFGVX.isChecked():
                randomlist=random.sample(range(36),36)
                for i in range(36):
                    ListOfLabels[i].setText(globalAlphabet[randomlist[i]])
        else:
            
            counter=5
            randomlist=random.sample(range(25),25)
            newAlphaWithouDigits=[]
            secondCounter=0
            for i in range(25):
                newAlphaWithouDigits.append(newAlphabet[i])
            for i in range(30):
                if i == counter:
                    counter=counter+6
                    continue
                else:
                    ListOfLabels[i].setText(newAlphaWithouDigits[randomlist[secondCounter]])
                    secondCounter=secondCounter+1
                                     
            
    def are_all_conditions_ok(self):
        result = True
        if(self.is_table_full()):
            QMessageBox.about(self,"Error","The table is not finished. Complete the table first")
            result=False
        if(self.is_table_repeating()):
            QMessageBox.about(self,"Error","The table must have non-repeating letter")
            result=False
        if(self.are_table_chars_not_ok()):
            QMessageBox.about(self,"Error","Table must include characters without diacritic")
            result=False
        if(self.is_text_not_ok()):
            QMessageBox.about(self,"Error","Open text muset be without diacritic")
            result=False
        if(self.is_keyword_not_ok()):
            QMessageBox.about(self,"Error","Keyword must include characters without diacritic")
            result=False
        if(self.is_keyword_not_entered()):
            QMessageBox.about(self,"Error","Enter keyword before ciphering")
            result=False
        if(self.is_ciphertext_not_ok()):
            QMessageBox.about(self,"Error","Ciphered text must contaion only alphabet characters or spaces")
            result=False
        if(self.is_CT_evev()):
            QMessageBox.about(self,"Error","Ciphered text must have even number of characters")
            result=False

        return result


        return result
    def is_table_full(self):
        counter=0
        if self.radioADFGX.isChecked():
            for letter in ListOfLabels:
                if letter.text() != "___":
                    counter=counter+1
            
            if counter < 25:
                return True
            else:
                return False
        else:
            for letter in ListOfLabels:
                if letter.text() != "___":
                    counter=counter+1
            if counter < 36:
                return True
            else:
                return False

    def are_table_chars_not_ok(self):
        result=True
        if self.radioADFGX.isChecked():
            for letter in ListOfLabels:
                if (bool(re.match('^[a-zA-Z___]*$',str(letter.text())))):
                    result=False
                else:
                    result=True
                    break
        else:
            for letter in ListOfLabels:
                if (bool(re.match('^[a-zA-Z0-9___]*$',str(letter.text())))):
                    result=False
                else:
                    result=True
                    break
        return result

    def is_table_repeating(self):
        result=False
        ListOfLabelsToString=""
        for i in ListOfLabels:
            if(i.text()!="___"):
                ListOfLabelsToString=ListOfLabelsToString+i.text()
        for i in range(len(ListOfLabelsToString)):
            for j in range(len(ListOfLabelsToString)):
                if(ListOfLabelsToString[i]==ListOfLabelsToString[j] and i!=j):
                    result=True 
                    break
            if(result):
                break
        return result

    def is_text_not_ok(self):
        result=False
        for letter in self.textBoxOT.toPlainText():
                if (bool(re.match('^[a-zA-Z0-9 ]*$',str(letter)))):
                    result=False
                else:
                    result=True
                    break
        return result



    def is_keyword_not_entered(self):
        result=False
        if self.keyword.text()=="":
            result=True
        else:
            result=False

        return result

    def is_keyword_not_ok(self):
        result=False
        for letter in self.keyword.text():
            if (bool(re.match('^[a-zA-Z0-9]*$',str(letter)))):
                result=False
            else:
                result=True
                break
        return result


    def replace_numbers_with_words(self,text):
        text=text.replace("0","NULA")
        text=text.replace("1","JEDNA")
        text=text.replace("2","DVA")
        text=text.replace("3","TRI")
        text=text.replace("4","CTYRI")
        text=text.replace("5","PET")
        text=text.replace("6","SEST")
        text=text.replace("7","SEDM")
        text=text.replace("8","OSM")
        text=text.replace("9","DEVET")
        return text

    def remove_repeating_chars_from_keyword(self,text):
        updatedKeyword="".join(dict.fromkeys(text))
        updatedKeyword=updatedKeyword.replace(" ","")
        return updatedKeyword


    def convert_labels_to_string(self):
        result=""
        for letter in ListOfLabels:
            if letter.text()!="___":
                result=result+letter.text()
        return result


    def get_ciphered_pair(self,rows,cols,text,table,IndexKey):
        pair=""
        X=0
        Y=0
        

        for i in range(rows):
            for j in range(cols):
                if table[i][j] == text:
                    pair=pair+IndexKey[i]+IndexKey[j]                    
        return pair
        
    def get_first_stage_CT(self,rows, cols,text,IndexKey):
        MultiDimTable = [[0 for i in range(cols)] for j in range(rows)]
        labels=self.convert_labels_to_string()
        counter=0
        for i in range(rows):
            for j in range(cols):
                MultiDimTable[i][j]=labels[counter]
                counter=counter+1
        CipheredPairs=""
        for letter in text:
            CipheredPairs=CipheredPairs+self.get_ciphered_pair(rows,cols,letter,MultiDimTable,IndexKey)
        return CipheredPairs



    def get_second_stage_CT(self,FirstStageCT,keyword):
        rows=int(len(FirstStageCT)/len(keyword))+1
        cols=len(keyword)
        counter=0
        MultiDimKeywordTable=[[0 for i in range(cols)] for j in range(rows)]
        for i in range(rows):
            for j in range(cols):
                if counter<len(FirstStageCT):
                    MultiDimKeywordTable[i][j]=FirstStageCT[counter]
                    counter+=1        
                else:
                    MultiDimKeywordTable[i][j]="_"
        
        UpdatedKeyword="".join(sorted(keyword.strip()))
        result=""
        for k in UpdatedKeyword:
            for i in range(rows):
                result+=MultiDimKeywordTable[i][keyword.index(k)]
            result+=" "
        result=result.replace("_","")
        return result



    def Cipher(self,text):
        if(self.are_all_conditions_ok()):
            self.remove_character_from_alpha(globalAlphabet)
            _text=self.replace_numbers_with_words(self.replace_left_out_letters(text))
            _keyword=self.remove_repeating_chars_from_keyword(self.replace_left_out_letters(self.keyword.text().upper()))

            if self.radioADFGX.isChecked():
                FirstStageCT=self.get_first_stage_CT(5,5,_text,"ADFGX")
            else:                
                FirstStageCT=self.get_first_stage_CT(6,6,_text,"ADFGVX")

            SecondStageCT=self.get_second_stage_CT(FirstStageCT,_keyword)
            self.textBoxCT.setPlainText(SecondStageCT)

            
        










    def is_ciphertext_not_ok(self):
        result=False
        for letter in self.textBoxCT.toPlainText():
                if (bool(re.match('^[a-zA-Z0-9 ]*$',str(letter)))) or letter==" ":
                    result=False
                else:
                    result=True
                    break
        return result


    def remove_space_from_CT(self,text):
        text=text.replace(" ","")
        return text


    def split_into_pairs(self,text):
        newArray=[]
        for i in range(0,len(text),2):
            newArray.append(text[i]+text[i+1])
        return newArray

    def is_CT_evev(self):
        if len(self.remove_space_from_CT(self.textBoxCT.toPlainText()))%2==0:
            return False
        else:
            return True

    def get_first_stage_OT(self,keyword,text):
        if len(text)%len(keyword)==0:
            rows=int(len(text)/len(keyword))
        else:
            rows=int(len(text)/len(keyword))+1

        cols=len(keyword)
        #QMessageBox.about(self,"as",text)
        counter=0
        UpdatedKeyword="".join(sorted(keyword.strip()))
        MultiDimKeywordTable=[[0 for i in range(cols)] for j in range(rows)]
        for i in range(cols):
            for j in range(rows):
                if counter<len(text):  
                    if(text[counter]==" "):
                        counter+=1
                        break

                    else:
                        MultiDimKeywordTable[j][i]=text[counter]
                        #QMessageBox.about(self,"as",str(MultiDimKeywordTable[j][i]))
                        counter+=1        
        
        result=""
        SecondMultiDimKeywordTable=[[0 for i in range(cols)] for j in range(rows)]
        counter=0
        for k in keyword:
            for i in range(rows):
                SecondMultiDimKeywordTable[i][counter]=MultiDimKeywordTable[i][UpdatedKeyword.index(k)]
                #QMessageBox.about(self,"sdsd",str(SecondMultiDimKeywordTable[i][counter]))            
            counter+=1
        for i in range(rows):
            for j in range(cols):
                result+=str(SecondMultiDimKeywordTable[i][j])
        result=result.replace(" ","")
        result=result.replace("_","")
        result=result.replace("0","")
        #QMessageBox.about(self,"as",result)
        return result


    def get_second_stage_OT(self,rows,cols,text,IndexKey):
        MultiDimTable = [[0 for i in range(cols)] for j in range(rows)]
        labels=self.convert_labels_to_string()
        counter=0
        result=""

        for i in range(rows):
            for j in range(cols):
                MultiDimTable[i][j]=labels[counter]
                counter=counter+1
        #QMessageBox.about(self,"as",text)
        CTtextInPairs=self.split_into_pairs(text)
        for pair in CTtextInPairs:
            for i in range(rows):
                for j in range(cols):
                    if pair[0] == IndexKey[i] and pair[1]==IndexKey[j]:
                        result+=str(MultiDimTable[i][j])

        #QMessageBox.about(self,"as",result)
        return result
    def Decipher(self,_text):
        if(self.are_all_conditions_ok()):
            
            _keyword=self.remove_repeating_chars_from_keyword(self.replace_left_out_letters(self.keyword.text().upper()))
            FirstStageOT=self.get_first_stage_OT(_keyword,_text)

            if self.radioADFGX.isChecked():
                SecondStageOT= self.get_second_stage_OT(5,5,FirstStageOT,"ADFGX")
            else:                
                SecondStageOT= self.get_second_stage_OT(6,6,FirstStageOT,"ADFGVX")

            self.textBoxOT.setPlainText(SecondStageOT)

      
        #self.cipherButton.clicked.connect(self.cipherButton_clicked)
        #self.decipherButton.clicked.connect(self.decipherButton_clicked)

    

app = QApplication(sys.argv)
win = MyWindow()
app.exec_()
